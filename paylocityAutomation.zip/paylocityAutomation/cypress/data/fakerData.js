import {faker} from '@faker-js/faker';
export const userData = {
    employeeFirstName : faker.person.firstName(),
    employeeLastNAme : faker.person.lastName()
}