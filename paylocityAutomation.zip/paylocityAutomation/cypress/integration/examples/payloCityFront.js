import DashboardPage from "../../support/ects/DashboardPage";
import LogInPage from "../../support/ects/LogInPage"


describe('End to End - Add, Edit and Delete Employee', function () {
    it('Add, Edit and Delete Employee', function () {
        const logInPage = new LogInPage();
        const dasboardPage = new DashboardPage();
        logInPage.goTo('https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/LogIn')
        logInPage.logIn()
        dasboardPage.openAddEmployeeModal();
        dasboardPage.addEmployeeFields();
        dasboardPage.editEmployeeFields();
        dasboardPage.deleteEmployee();
    })
    
})