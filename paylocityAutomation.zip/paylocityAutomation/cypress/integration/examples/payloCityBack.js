describe('paylocity API Validation', function () {
    let savedId = Cypress.env('savedId');
    const token = 'VGVzdFVzZXI3MjI6JDgoOzY1UFdGWHZI';
    it('Get Employee List', function () {
       cy.request({
        method: 'GET',
        url:`https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/api/employees`,
        headers: {
            Connection: "keep-alive",
            authorization: `Basic ${token}`,
        }
    }).then((resp) =>{
        expect(resp.status).to.eq(200)
        expect(resp.body).to.be.an('array');
        resp.body.forEach((element) => {
                expect(element).to.have.property('id');
                expect(element).to.have.property('firstName');
                expect(element).to.have.property('lastName');
                expect(element).to.have.property('dependants');

        })
    })
       })

       it('Add Employee', function() {
       cy.request({
        method: 'POST',
        url:`https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/api/employees`,
        headers: {
            Connection: "keep-alive",
            authorization: `Basic ${token}`,
        },
        body:{
            "firstName": "Natasha",
            "lastName": "Romanoff",
            "dependants": 3
        }

    }).then((resp) =>{
        expect(resp.status).to.eq(200)
        expect(resp.body).to.be.an('object');
        expect(resp.body).to.have.property('id');
        savedId = resp.body.id;
        cy.log('saved Id: ', savedId);
       })
       cy.wait(3000);
    })
   it('Get Employee by Id', function(){
        cy.request({
            method: 'GET',
            url:`https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/api/employees/${savedId}`,
            headers: {
                Connection: "keep-alive",
                authorization: `Basic ${token}`,
            }
        }).then((resp) =>{
        expect(resp.status).to.eq(200);
        expect(resp.body).to.have.property('id', savedId);  
        })
    })
    it('Update Employee - Dependents', function() {
        cy.request({
         method: 'POST',
         url:`https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/api/employees`,
         headers: {
             Connection: "keep-alive",
             authorization: `Basic ${token}`,
         },
         body:{
             "firstName": "Natasha",
             "lastName": "Romanoff",
             "dependants": 4
         }
 
     }).then((resp) =>{
         expect(resp.status).to.eq(200)
         expect(resp.body).to.be.an('object');
         expect(resp.body).to.have.property('dependants');
         expect(resp.body.dependants).to.eq(4);
         expect(resp.body.net).to.eq(1884.6154);
        })
        cy.wait(3000);
        
     })
     it('Delete Employee', function(){
        cy.request({
            method: 'GET',
            url:`https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/api/employees/${savedId}`,
            headers: {
                Connection: "keep-alive",
                authorization: `Basic ${token}`,
            }
        }).then((resp) =>{
        expect(resp.status).to.eq(200);
        })
        cy.wait(2000);
    })
    
})