describe('pockemon project', function () {
    it('Header validation', function () {
        cy.request('https://pokeapi.co/api/v2/pokemon/25').as('pockemon');
        cy.get('@pockemon').its('headers').its('content-type')
            .should('include', 'application/json; charset=utf-8');
    })
    it('status validation', function () {
        cy.request('https://pokeapi.co/api/v2/pokemon/25').as('pockemon');
        cy.get('@pockemon').its('status')
            .should('equal', 200)
    })
    it('status validation another path', function () {
        cy.request('https://pokeapi.co/api/v2/pokemon/25').then((resp) =>{
            expect(resp.status).to.eq(200)
            expect(resp.body).to.have.property('name','pikachu')
         })
    })

    it('body validations', function () {
        cy.request('https://pokeapi.co/api/v2/pokemon/25').as('pockemon');
        cy.get('@pockemon').its('body')
            .should('include', {name:'pikachu'})
    })
    it('negative request', function () {
        cy.request({
            method: 'GET',
            url:'https://pokeapi.co/api/v2/pokemon/10000',
            failOnStatusCode: false
        }).then((resp) =>{
            expect(resp.status).to.eq(404)
          
         })
    })
})