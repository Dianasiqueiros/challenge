class LogInPage {
    goTo(url) {
        cy.visit(url);
       }

    logIn() {
        cy.get("#Username").type('TestUser722');
        cy.get("#Password").type('$8(;65PWFXvH');
        cy.contains('Log In').click();
        cy.get('.navbar-brand').should('have.text', 'Paylocity Benefits Dashboard');

    }
}
export default LogInPage;