class DashboardPage{
    openAddEmployeeModal(){
        cy.get('#add').contains('Add Employee').click();
        cy.get('.navbar-brand').should('have.text', 'Paylocity Benefits Dashboard');
        cy.get('.modal-title').contains('Add Employee').should('be.visible');

    }
    addEmployeeFields(){
        cy.get('#firstName').type('Checo');
        cy.get('#lastName').type('Perez');
        cy.get('#dependants').type('1');
        cy.get('#addEmployee').contains('Add').click();
        cy.get('tr').filter(':contains("Checo")')
        .within(() =>{
            cy.get('td').eq(3).should('have.text', '1');
            cy.get('td').eq(4).should('have.text', '52000.00');
            cy.get('td').eq(5).should('have.text', '2000.00');
            cy.get('td').eq(6).should('have.text', '57.69');
            cy.get('td').eq(7).should('have.text', '1942.31');

        })
    }
    editEmployeeFields(){
        cy.get('tr').filter(':contains("Checo")')
        .within(() =>{
            cy.get('.fa-edit').click();
        })
        cy.get('#dependants').click();
        cy.get('input[name="dependants"]').clear().type('2');
        cy.get('#updateEmployee').contains('Update').click();
        cy.wait(2000); // Espera 2 segundos
        cy.get('tr').filter(':contains("Perez")')
        .within(() =>{
            cy.get('td').eq(3).should('have.text', '2');
            cy.get('td').eq(4).should('have.text', '52000.00');
            cy.get('td').eq(5).should('have.text', '2000.00');
            cy.get('td').eq(6).should('have.text', '76.92');
            cy.get('td').eq(7).should('have.text', '1923.08');
        })
    }
    deleteEmployee(){
        cy.get('tr').filter(':contains("Checo")')
        .within(() =>{
            cy.get('.fa-times').click();

        })
        cy.contains('Delete employee record for Checo Perez?').should('be.visible');
        cy.get('#deleteEmployee').click();
        cy.wait(2000); 
        cy.contains('Checo').should('be.not.visible');
    }
    

}
export default DashboardPage;